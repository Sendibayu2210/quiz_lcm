<nav class="navbar navbar-expand-lg bg-transparent mb-3  position-absolute w-100" style="z-index: 5;">
  <div class="container-fluid"> 
    <a class="navbar-brand- h5" href="#" v-html="titlePage"></a>           

    <div class="collapse navbar-collapse" id="navbarSupportedContent">          
      <div class="d-flex w-100 justify-content-end py-2 align-items-center text-dark cursor-pointer" id="navbar-profile">        
        <div>                
              <a href="/register" class="btn ms-2 btn-outline-primary bg-white text-primary px-4 btn-sm br-10">Register</a>             
              <a href="/login" class="btn ms-2 btn-primary px-4 btn-sm br-10">Login</a>             
        </div>
      </div>
    </div>    
  </div>
</nav>